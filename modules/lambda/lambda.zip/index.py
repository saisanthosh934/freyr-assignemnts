import json
import urllib3

def handler(event, context):
    if 'test_connectivity' in event:
        
        http = urllib3.PoolManager()
        results = {}
        
        alb_urls = event.get('alb_urls', {})
        for app, url in alb_urls.items():
            try:
                resp = http.request('GET', url)
                results[app] = {'status': resp.status, 'data': resp.data.decode()}
            except Exception as e:
                results[app] = {'error': str(e)}
        
        return {'statusCode': 200, 'body': json.dumps(results)}
    
    
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'application/json'},
        'body': json.dumps({'message': 'Hello from Lambda!'})
    }
